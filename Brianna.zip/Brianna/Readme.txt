Have different words for her to read. Start with 2 and 3 letter words

have different cool pictures that change in the profile pic to keep it cool

